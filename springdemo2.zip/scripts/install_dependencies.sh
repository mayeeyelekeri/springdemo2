#!/bin/bash
yum install -y docker

